#include "example.h"
#include <iostream>

void HelloWorld()
{
    std::cout << "Hello World!" << std::endl;
}